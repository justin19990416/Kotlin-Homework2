package com.example.lab5 // 套件名稱；需與 AndroidManifest 相同

import android.os.Bundle // 匯入 Bundle：提供生命週期參數
import android.util.Log // 匯入 Log：輸出除錯訊息
import androidx.appcompat.app.AppCompatActivity // 匯入 AppCompatActivity：Activity 基底
import androidx.core.view.ViewCompat // 匯入 ViewCompat：設定 WindowInsets 監聽
import androidx.core.view.WindowCompat // 匯入 WindowCompat：edge-to-edge 相容寫法
import androidx.core.view.WindowInsetsCompat // 匯入 WindowInsetsCompat：讀取系統列 insets
import androidx.viewpager2.widget.ViewPager2 // 匯入 ViewPager2：分頁元件

class MainActivity : AppCompatActivity() { // 宣告 MainActivity，繼承 AppCompatActivity

    companion object { // 伴生物件：集中常數
        private const val TAG = "MainActivity" // 日誌標籤；Logcat 過濾用
    }

    override fun onCreate(savedInstanceState: Bundle?) { // onCreate：Activity 入口
        super.onCreate(savedInstanceState) // 呼叫父類別，完成框架初始化
        WindowCompat.setDecorFitsSystemWindows(window, false) // 啟用 edge-to-edge（舊新版本皆相容）
        setContentView(R.layout.activity_main) // 設定佈局檔（需存在 res/layout/activity_main.xml）

        val root = findViewById<android.view.View>(R.id.main) // 取得根視圖（XML 根節點請設 id="main"）
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets -> // 監聽 WindowInsets 變化
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()) // 取得狀態列/導覽列 insets
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom) // 動態加內距，避免內容被遮住
            insets // 回傳原始 insets
        }

        Log.d(TAG, "onCreate") // 輸出生命週期日誌：onCreate

        val viewPager2 = findViewById<ViewPager2>(R.id.viewPager2) // 取得 ViewPager2 實例（id 必須為 viewPager2）
        val adapter = ViewPagerAdapter(supportFragmentManager, lifecycle) // 建立 Adapter（FragmentStateAdapter 需傳 FM 與 Lifecycle）
        viewPager2.adapter = adapter // 指定 Adapter 給 ViewPager2
        viewPager2.offscreenPageLimit = 1 // 預載相鄰 1 個頁面（效能/流暢度折衷）

        viewPager2.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() { // 註冊頁面切換回呼
            override fun onPageSelected(position: Int) { // 當某頁被選取
                Log.d(TAG, "Page selected: $position") // 印出當前頁索引
            }
        }) // 結束回呼註冊
    }

    override fun onRestart() { // 從停止狀態回到可見前
        super.onRestart() // 呼叫父類別
        Log.d(TAG, "onRestart") // 生命週期日誌
    }

    override fun onStart() { // 變得可見
        super.onStart() // 呼叫父類別
        Log.d(TAG, "onStart") // 生命週期日誌
    }

    override fun onResume() { // 進入前景可互動
        super.onResume() // 呼叫父類別
        Log.d(TAG, "onResume") // 生命週期日誌
    }

    override fun onPause() { // 即將離開前景
        super.onPause() // 呼叫父類別
        Log.d(TAG, "onPause") // 生命週期日誌
    }

    override fun onStop() { // 不再可見
        super.onStop() // 呼叫父類別
        Log.d(TAG, "onStop") // 生命週期日誌
    }

    override fun onDestroy() { // 即將被銷毀
        super.onDestroy() // 呼叫父類別
        Log.d(TAG, "onDestroy") // 生命週期日誌
    }
}
