package com.example.lab5 // 套件名稱；需與 Manifest 一致

import android.content.Context // 匯入 Context
import android.os.Bundle // 匯入 Bundle
import android.util.Log // 匯入 Log
import android.view.LayoutInflater // 匯入 LayoutInflater
import android.view.View // 匯入 View
import android.view.ViewGroup // 匯入 ViewGroup
import androidx.fragment.app.Fragment // 匯入 Fragment

class SecondFragment : Fragment() { // 宣告 SecondFragment

    companion object { // 伴生物件
        private const val TAG = "SecondFragment" // 日誌標籤
    }

    override fun onAttach(context: Context) { // 與宿主關聯
        super.onAttach(context) // 呼叫父類別
        Log.d(TAG, "onAttach") // 印生命週期
    }

    override fun onCreate(savedInstanceState: Bundle?) { // 物件建立
        super.onCreate(savedInstanceState) // 呼叫父類別
        Log.d(TAG, "onCreate") // 印生命週期
    }

    override fun onCreateView( // 建立 UI
        inflater: LayoutInflater, // XML 充氣器
        container: ViewGroup?, // 父容器
        savedInstanceState: Bundle? // 狀態
    ): View { // 回傳根 View
        Log.d(TAG, "onCreateView") // 印生命週期
        return inflater.inflate(R.layout.fragment_second, container, false) // 以 XML 建立視圖
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) { // 視圖建立完成
        super.onViewCreated(view, savedInstanceState) // 呼叫父類別
        Log.d(TAG, "onViewCreated") // 印生命週期
        // 這裡可用 view.findViewById(...) 綁定元件 // 說明：不使用 ViewBinding 的情境
    }

    override fun onStart() { super.onStart(); Log.d(TAG, "onStart") } // 變可見
    override fun onResume() { super.onResume(); Log.d(TAG, "onResume") } // 可互動
    override fun onPause() { Log.d(TAG, "onPause"); super.onPause() } // 將離開前景
    override fun onStop() { Log.d(TAG, "onStop"); super.onStop() } // 不再可見
    override fun onDestroyView() { Log.d(TAG, "onDestroyView"); super.onDestroyView() } // 視圖銷毀
    override fun onDestroy() { Log.d(TAG, "onDestroy"); super.onDestroy() } // 物件銷毀
    override fun onDetach() { Log.d(TAG, "onDetach"); super.onDetach() } // 與宿主解綁
}
