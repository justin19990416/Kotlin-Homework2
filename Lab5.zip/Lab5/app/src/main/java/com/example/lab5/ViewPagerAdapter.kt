package com.example.lab5 // 套件名稱；需與 AndroidManifest 相符，確保可正確定位類別

import androidx.annotation.IntRange // 匯入註解；用於限制整數參數範圍（提升可讀性與靜態檢查）
import androidx.fragment.app.Fragment // 匯入 Fragment 基底類別
import androidx.fragment.app.FragmentManager // 匯入 FragmentManager；交給 FragmentStateAdapter 管理片段
import androidx.lifecycle.Lifecycle // 匯入 Lifecycle；提供適配器生命週期控制
import androidx.viewpager2.adapter.FragmentStateAdapter // 匯入 ViewPager2 的 Fragment 適配器

/**
 * 優化重點：
 * 1) 以「Fragment 產生器清單」取代 when/else，擴充頁數時只需新增清單項目即可（開閉原則）。
 * 2) 覆寫 getItemId()/containsItem() 提供穩定 ID，旋轉或資料更新時更穩定（避免不必要重建）。
 * 3) 使用 @IntRange 約束 position 參數，並以 require() 做邊界保護，避免越界崩潰。
 */
class ViewPagerAdapter( // 宣告適配器類別，提供給 ViewPager2 使用
    fm: FragmentManager, // 建構子參數：FragmentManager（由 Activity 交付）
    lifecycle: Lifecycle // 建構子參數：Lifecycle（由 Activity 交付）
) : FragmentStateAdapter(fm, lifecycle) { // 繼承 FragmentStateAdapter，將分頁與生命週期交由父類別管理

    // 以函式清單保存每一頁的 Fragment 建立邏輯（::ClassName 取得無參數建構子的函式參考）
    private val creators: List<() -> Fragment> = listOf( // 宣告不可變清單；順序即分頁順序
        ::FirstFragment,  // 第 0 頁：回傳 FirstFragment 的建構子參考
        ::SecondFragment, // 第 1 頁：回傳 SecondFragment 的建構子參考
        ::ThirdFragment   // 第 2 頁：回傳 ThirdFragment 的建構子參考
    )

    // 以穩定的「頁面鍵」清單作為每頁的 Stable ID 來源（可用類名或自定義常數）
    private val pageKeys: List<Long> = listOf( // 宣告每頁對應的長整數鍵
        "FirstFragment".hashCode().toLong(),  // 第 0 頁的穩定鍵（由類名字串雜湊而來）
        "SecondFragment".hashCode().toLong(), // 第 1 頁的穩定鍵
        "ThirdFragment".hashCode().toLong()   // 第 2 頁的穩定鍵
    )

    override fun getItemCount(): Int = creators.size // 回傳分頁數量＝產生器清單長度（擴充時自動更新）

    override fun createFragment(
        @IntRange(from = 0) position: Int // 使用 @IntRange 標註，提示呼叫端合法範圍
    ): Fragment { // 覆寫：依索引建立對應 Fragment
        require(position in creators.indices) { "Invalid position: $position" } // 邊界檢查；非合法索引即丟出例外，避免 NPE
        return creators[position].invoke() // 呼叫對應的產生器函式，建立並回傳 Fragment 實例
    }

    // 提供「穩定 ID」以提升狀態還原與更新穩定度（例如螢幕旋轉或資料集變動）
    override fun getItemId(position: Int): Long { // 覆寫：回傳該位置的唯一長整數 ID
        require(position in pageKeys.indices) { "Invalid position for ID: $position" } // 邊界檢查；確保不越界
        return pageKeys[position] // 依索引回傳對應的穩定鍵
    }

    // 告訴適配器目前的 ID 是否仍存在（若動態增刪頁面時很重要）
    override fun containsItem(itemId: Long): Boolean { // 覆寫：檢查指定 ID 是否屬於目前資料集
        return pageKeys.contains(itemId) // 回傳是否存在於 pageKeys 清單中
    }
}
