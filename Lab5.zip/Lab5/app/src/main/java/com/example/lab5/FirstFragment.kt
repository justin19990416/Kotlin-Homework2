package com.example.lab5 // 套件名稱；需與目錄/Manifest 一致

import android.content.Context // 匯入 Context（onAttach 用）
import android.os.Bundle // 匯入 Bundle（生命週期狀態）
import android.util.Log // 匯入 Log（除錯用）
import android.view.LayoutInflater // 匯入 LayoutInflater（充氣 XML）
import android.view.View // 匯入 View（視圖節點）
import android.view.ViewGroup // 匯入 ViewGroup（容器）
import androidx.fragment.app.Fragment // 匯入 Fragment 基底

class FirstFragment : Fragment() { // 宣告 FirstFragment

    companion object { // 伴生物件：集中常數
        private const val TAG = "FirstFragment" // 日誌標籤
    }

    override fun onAttach(context: Context) { // Fragment 與 Activity 關聯
        super.onAttach(context) // 呼叫父類別
        Log.d(TAG, "onAttach") // 輸出生命週期
    }

    override fun onCreate(savedInstanceState: Bundle?) { // Fragment 建立（尚未建視圖）
        super.onCreate(savedInstanceState) // 父類別初始化
        Log.d(TAG, "onCreate") // 生命週期日誌
    }

    override fun onCreateView( // 建立並回傳 UI 視圖
        inflater: LayoutInflater, // 充氣器
        container: ViewGroup?, // 父容器
        savedInstanceState: Bundle? // 先前狀態
    ): View { // 回傳 View
        Log.d(TAG, "onCreateView") // 生命週期日誌
        return inflater.inflate(R.layout.fragment_first, container, false) // 以 XML 建立視圖
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) { // 視圖已建立
        super.onViewCreated(view, savedInstanceState) // 父類別
        Log.d(TAG, "onViewCreated") // 生命週期日誌
        // 這裡可透過 view.findViewById(...) 綁定元件並設定事件 // 中文註解：說明用
    }

    override fun onStart() { // 變可見
        super.onStart() // 父類別
        Log.d(TAG, "onStart") // 生命週期日誌
    }

    override fun onResume() { // 可互動
        super.onResume() // 父類別
        Log.d(TAG, "onResume") // 生命週期日誌
    }

    override fun onPause() { // 將離開前景
        Log.d(TAG, "onPause") // 生命週期日誌
        super.onPause() // 父類別
    }

    override fun onStop() { // 不再可見
        Log.d(TAG, "onStop") // 生命週期日誌
        super.onStop() // 父類別
    }

    override fun onDestroyView() { // 視圖被銷毀
        Log.d(TAG, "onDestroyView") // 生命週期日誌
        super.onDestroyView() // 父類別
    }

    override fun onDestroy() { // Fragment 銷毀
        Log.d(TAG, "onDestroy") // 生命週期日誌
        super.onDestroy() // 父類別
    }

    override fun onDetach() { // 與 Activity 解除關聯
        Log.d(TAG, "onDetach") // 生命週期日誌
        super.onDetach() // 父類別
    }
}
