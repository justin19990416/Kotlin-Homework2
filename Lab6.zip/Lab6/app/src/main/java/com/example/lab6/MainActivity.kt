package com.example.lab6 // 套件名稱；要與 Manifest 一致

import android.os.Bundle // 生命週期參數
import android.widget.Button // 取得按鈕元件
import android.widget.Toast // 顯示短訊息
import androidx.appcompat.app.AlertDialog // 建立對話框
import androidx.appcompat.app.AppCompatActivity // 基底 Activity
import androidx.core.view.ViewCompat // WindowInsets 監聽
import androidx.core.view.WindowCompat // edge-to-edge 相容寫法
import androidx.core.view.WindowInsetsCompat // 取得系統列 insets
import com.google.android.material.snackbar.Snackbar // Snackbar 提示

class MainActivity : AppCompatActivity() { // 宣告 MainActivity

    override fun onCreate(savedInstanceState: Bundle?) { // 入口
        super.onCreate(savedInstanceState) // 父類別初始化
        WindowCompat.setDecorFitsSystemWindows(window, false) // 啟用 edge-to-edge
        setContentView(R.layout.activity_main) // 設定畫面（需有 activity_main.xml）

        val root = findViewById<android.view.View>(R.id.main) // 取得根視圖（XML 請設 id="main"）
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets -> // 監聽 insets
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()) // 系統列尺寸
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom) // 套用 padding
            insets // 回傳 insets
        }

        // 綁定元件
        val btnToast = findViewById<Button>(R.id.btnToast) // Toast 按鈕
        val btnSnackBar = findViewById<Button>(R.id.btnSnackBar) // Snackbar 按鈕
        val btnDialog1 = findViewById<Button>(R.id.btnDialog1) // 三鍵 Dialog
        val btnDialog2 = findViewById<Button>(R.id.btnDialog2) // 列表 Dialog
        val btnDialog3 = findViewById<Button>(R.id.btnDialog3) // 單選 Dialog

        val items = arrayOf("選項 1", "選項 2", "選項 3", "選項 4", "選項 5") // 清單資料

        btnToast.setOnClickListener { // 點擊 Toast
            showToast("預設 Toast") // 顯示訊息
        }

        btnSnackBar.setOnClickListener { view -> // 點擊 Snackbar
            Snackbar.make(view, "按鈕式 Snackbar", Snackbar.LENGTH_SHORT) // 建立 Snackbar
                .setAction("按鈕") { showToast("已回應") } // 設定動作鍵
                .show() // 顯示
        }

        btnDialog1.setOnClickListener { // 三鍵對話框
            AlertDialog.Builder(this) // 建構器
                .setTitle("按鈕式 AlertDialog") // 標題
                .setMessage("AlertDialog 內容") // 內文
                .setNeutralButton("左按鈕") { _, _ -> showToast("左按鈕") } // 中立鍵
                .setNegativeButton("中按鈕") { _, _ -> showToast("中按鈕") } // 負向鍵
                .setPositiveButton("右按鈕") { _, _ -> showToast("右按鈕") } // 正向鍵
                .show() // 顯示
        }

        btnDialog2.setOnClickListener { // 列表對話框
            AlertDialog.Builder(this)
                .setTitle("列表式 AlertDialog")
                .setItems(items) { _, i -> showToast("你選的是${items[i]}") } // 點選顯示
                .show()
        }

        btnDialog3.setOnClickListener { // 單選對話框
            var position = 0 // 暫存選中的索引
            AlertDialog.Builder(this)
                .setTitle("單選式 AlertDialog") // 標題
                .setSingleChoiceItems(items, 0) { _, i -> position = i } // 預設第一項
                .setPositiveButton("確定") { _, _ -> showToast("你選的是${items[position]}") } // 確認
                .show()
        }
    }

    private fun showToast(msg: String) { // 共用：顯示 Toast
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() // 建立並顯示
    }
}
