package com.example.lab4 // 套件名稱；需與 AndroidManifest 一致

import android.app.Activity // 匯入 RESULT_OK 等常數
import android.content.Intent // 匯入 Intent
import android.os.Bundle // 匯入 Bundle
import android.widget.Button // 匯入 Button
import android.widget.TextView // 匯入 TextView
import androidx.activity.result.ActivityResult // 匯入 ActivityResult
import androidx.activity.result.contract.ActivityResultContracts // 匯入結果合約
import androidx.appcompat.app.AppCompatActivity // 匯入 AppCompatActivity
import androidx.core.view.ViewCompat // 匯入 ViewCompat
import androidx.core.view.WindowCompat // 匯入 WindowCompat（舊版相容的 edge-to-edge）
import androidx.core.view.WindowInsetsCompat // 匯入 WindowInsetsCompat

class MainActivity : AppCompatActivity() { // 宣告 MainActivity

    companion object { // companion：集中 Intent Key
        const val EXTRA_DRINK = "drink" // 飲料名稱 Key
        const val EXTRA_SUGAR = "sugar" // 甜度 Key
        const val EXTRA_ICE = "ice" // 冰塊 Key
    }

    private lateinit var tvMeal: TextView // 宣告 TextView 變數（稍後用 findViewById 綁定）

    // 註冊結果啟動器：啟動 SecActivity 並接收結果
    private val startForResult = registerForActivityResult( // 建立啟動器
        ActivityResultContracts.StartActivityForResult() // 指定合約
    ) { result: ActivityResult -> // 回呼取得結果
        if (result.resultCode == Activity.RESULT_OK) { // 確認結果代碼
            val data = result.data ?: return@registerForActivityResult // 取得 Intent；null 則返回
            val drink = data.getStringExtra(EXTRA_DRINK).orEmpty() // 取出飲料字串
            val sugar = data.getStringExtra(EXTRA_SUGAR).orEmpty() // 取出甜度字串
            val ice = data.getStringExtra(EXTRA_ICE).orEmpty() // 取出冰塊字串
            tvMeal.text = "飲料：$drink\n\n甜度：$sugar\n\n冰塊：$ice" // 更新畫面文字
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) { // onCreate：初始化
        super.onCreate(savedInstanceState) // 呼叫父類別
        setContentView(R.layout.activity_main) // 設定畫面佈局（使用既有 XML）

        WindowCompat.setDecorFitsSystemWindows(window, false) // 舊式 edge-to-edge 寫法，廣泛相容
        val root = findViewById<android.view.View>(R.id.main) // 取得根視圖（需在 XML 設 id=main）
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets -> // 設定 insets 監聽
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()) // 取得系統列邊距
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom) // 套用安全內距
            insets // 返回 insets
        }

        val btnChoice = findViewById<Button>(R.id.btnChoice) // 綁定選擇按鈕
        tvMeal = findViewById(R.id.tvMeal) // 綁定顯示結果的 TextView

        btnChoice.setOnClickListener { // 設定按鈕點擊事件
            val intent = Intent(this, SecActivity::class.java) // 建立跳轉 Intent
            startForResult.launch(intent) // 啟動並等待結果
        }
    }
}
