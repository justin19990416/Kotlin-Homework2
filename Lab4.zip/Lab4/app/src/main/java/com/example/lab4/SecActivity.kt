package com.example.lab4 // 套件名稱；需與 AndroidManifest.xml 一致

import android.content.Intent // 匯入 Intent 以回傳資料
import android.os.Bundle // 匯入 Bundle 取得生命週期參數
import android.widget.Button // 匯入 Button 控制元件
import android.widget.RadioButton // 匯入 RadioButton 以讀取選項文字
import android.widget.RadioGroup // 匯入 RadioGroup 取得被選取之按鈕
import android.widget.TextView // 匯入 TextView 以讀取飲料名稱
import android.widget.Toast // 匯入 Toast 以顯示提示訊息
import androidx.appcompat.app.AppCompatActivity // 匯入 AppCompatActivity 作為基底類別
import androidx.core.view.ViewCompat // 匯入 ViewCompat 以處理 WindowInsets
import androidx.core.view.WindowInsetsCompat // 匯入 WindowInsetsCompat 取得系統列內距
import androidx.core.view.WindowCompat // 匯入 WindowCompat 以相容方式設定 edge-to-edge

class SecActivity : AppCompatActivity() { // 宣告 SecActivity，繼承 AppCompatActivity

    companion object { // companion 物件；集中 Intent Key，避免魔術字串
        const val EXTRA_DRINK = "drink" // 飲料名稱的 Key
        const val EXTRA_SUGAR = "sugar" // 甜度的 Key
        const val EXTRA_ICE = "ice" // 冰塊的 Key
    }

    override fun onCreate(savedInstanceState: Bundle?) { // 覆寫 onCreate，Activity 入口點
        super.onCreate(savedInstanceState) // 呼叫父類別以完成基本初始化
        setContentView(R.layout.activity_sec) // 指定畫面佈局檔（需存在 res/layout/activity_sec.xml）

        WindowCompat.setDecorFitsSystemWindows(window, false) // 啟用 edge-to-edge 相容寫法（比 enableEdgeToEdge 更不挑版本）
        val root = findViewById<android.view.View>(R.id.main) // 取得根視圖（XML 根節點請設 id="main"）
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets -> // 設定 WindowInsets 監聽
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()) // 取得系統列（狀態列/導覽列）內距
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom) // 套用安全內距，避免內容被遮擋
            insets // 回傳 insets 結束處理
        }

        // 取得畫面元件參考
        val edDrink = findViewById<TextView>(R.id.edDrink) // 取得輸入飲料名稱的 TextView/EditText（id 必須為 edDrink）
        val rgSugar = findViewById<RadioGroup>(R.id.rgSugar) // 取得甜度選項群組（id 必須為 rgSugar）
        val rgIce = findViewById<RadioGroup>(R.id.rgIce) // 取得冰塊選項群組（id 必須為 rgIce）
        val btnSend = findViewById<Button>(R.id.btnSend) // 取得送出按鈕（id 必須為 btnSend）

        btnSend.setOnClickListener { // 綁定送出按鈕的點擊事件
            val drink = edDrink.text?.toString()?.trim().orEmpty() // 讀取飲料名稱並去除空白，null 則給空字串
            if (drink.isEmpty()) { // 若飲料名稱為空
                Toast.makeText(this, "請輸入飲料名稱", Toast.LENGTH_SHORT).show() // 顯示提示訊息
                return@setOnClickListener // 中止流程等待使用者輸入
            }

            val sugarId = rgSugar.checkedRadioButtonId // 取得甜度被選取的按鈕 ID（-1 代表未選）
            if (sugarId == -1) { // 若尚未選擇甜度
                Toast.makeText(this, "請選擇甜度", Toast.LENGTH_SHORT).show() // 提示使用者
                return@setOnClickListener // 中止流程
            }
            val sugar = findViewById<RadioButton>(sugarId).text.toString() // 透過 ID 找到 RadioButton 並取其文字

            val iceId = rgIce.checkedRadioButtonId // 取得冰塊被選取的按鈕 ID
            if (iceId == -1) { // 若尚未選擇冰塊
                Toast.makeText(this, "請選擇冰塊", Toast.LENGTH_SHORT).show() // 提示使用者
                return@setOnClickListener // 中止流程
            }
            val ice = findViewById<RadioButton>(iceId).text.toString() // 透過 ID 找到 RadioButton 並取其文字

            val result = Intent().apply { // 建立用於回傳資料的 Intent
                putExtra(EXTRA_DRINK, drink) // 放入飲料名稱
                putExtra(EXTRA_SUGAR, sugar) // 放入甜度
                putExtra(EXTRA_ICE, ice) // 放入冰塊
            } // 完成 Intent 建構

            setResult(RESULT_OK, result) // 設定回傳結果為成功並附帶資料
            finish() // 關閉當前 Activity，返回上一頁（MainActivity 會在回呼中接收資料）
        }
    }
}
